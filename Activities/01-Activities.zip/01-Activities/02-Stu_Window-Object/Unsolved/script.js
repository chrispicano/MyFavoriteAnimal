// TODO: What will the following line of code log?
console.log(window);
// Window with all methods within in 

// TODO: What will the following line of code log?
console.log(window.document);
// The document within the window. represents any web page loaded in the browser and serves as an entry point into the web page's content, which is the DOM tree

// TODO: What will the following line of code log?
console.log(document.documentElement);
// logs all 



// TODO: What will the following line of code log?
console.log(document.head);

console.log(window.self.length);