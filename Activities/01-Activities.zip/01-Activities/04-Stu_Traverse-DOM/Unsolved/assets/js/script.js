// Access element using id
var articlesDiv = document.getElementById("articles");
var mainDiv = document.getElementById("main");

// Change style by accessing style object's properties
articlesDiv.children[2].style.fontSize = "50px";
mainDiv.style.color = "white";
